The input consists of two integers A and B separated by a space.

Constraints:\n- $-1000 \leq A, B \leq 1000$